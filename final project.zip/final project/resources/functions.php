<?php


// helper functions
function row_count($result)
{
    return mysqli_num_rows($result);
}
function clean($string)
{
    return htmlentities($string);
}
function token_generator()
{
 $token=$_SESSION['token']=md5(uniqid(mt_rand(),true));
 return $token;
}
function last_id(){
global $connection;
return mysqli_insert_id($connection);
}
function set_message($msg){
if(!empty($msg)) {
$_SESSION['message'] = $msg;
} else {
$msg = "";
    }
}
function display_message() {
    if(isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
}
function redirect($location){
return header("Location: $location ");
}

function query($sql) {
global $connection;
return mysqli_query($connection, $sql);
}
function confirm($result){
global $connection;
if(!$result) {
die("QUERY FAILED " . mysqli_error($connection));
	}
}
function escape_string($string){
global $connection;
return mysqli_real_escape_string($connection, $string);
}
function fetch_array($result){
return mysqli_fetch_array($result);
}
/***********************FRONT END FUNCTIONS*********************/
function login()
{
    if(isset($_POST['submit'])){
        $email    = escape_string($_POST['email']);
        $password = escape_string($_POST['password']);
        
        if(strlen($email)>0 && strlen($password)>0)
        {
        $query = query("SELECT * FROM bloodcenters WHERE bloodCenterEmail = '{$email}'");
            
            
        $uquery = query("SELECT * FROM users WHERE userEmail = '{$email}'");
            
            
        confirm($query);
            
        confirm($uquery);
            /* Blood Center */
            if(mysqli_num_rows($uquery) == 0 && mysqli_num_rows($query)>0)
            {
                    while($row=fetch_array($query))
                    {
                            $db_email=$row['bloodCenterEmail'];
                            $db_name =$row['bloodCenterName'];
                            $db_password=$row['bloodCenterPassword'];
                            $db_user_role=$row['bloodCenterUserRole'];
                            
                            
                            
                            if(mysqli_num_rows($query) == 0)
                            {
                                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                                <strong>Ohh....NO! Username does not exist</strong> 
                                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                <span aria-hidden='true'>&times;</span>
                                </button>
                                </div>");
                                redirect("login.php");
                            }
                            else
                            {
                                
                                $decrypted_pass = encrypt_decrypt('decrypt', $db_password);
                                
                                
                                if ( $decrypted_pass === $password )
                                {
                                    
                                    if($email==$db_email && $db_user_role=='admin')
                                    {
                                        
                                        $_SESSION['admin'] = $db_name;
                                        redirect("admin");
                                    }
                                    else if($email==$db_email && $db_user_role=='user' )
                                    {
                                        
                                        $_SESSION['user'] = $db_name;
                                        
                                        redirect("admin");
                                    }
                                    
                                }
                                else
                                {
                                    
                                    set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                    </button>
                                    Wrong password entered
                                    </div>");
                                    redirect("login.php");
                                    
                                }
                                
                                
                
                        }
                
        
                    }
            }
            /* Normal User */
            else if(mysqli_num_rows($uquery)>0 && mysqli_num_rows($query)==0)
            {
                    while($row=fetch_array($uquery))
                    {
                            $db_email=$row['userEmail'];
                            $db_name =$row['userName'];
                            $db_id =$row['userID'];
                            $db_password=$row['userPassword'];
                        
                
                            
                            
                            if(mysqli_num_rows($uquery) == 0)
                            {
                                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                                <strong>Ohh....NO! Username does not exist</strong> 
                                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                <span aria-hidden='true'>&times;</span>
                                </button>
                                </div>");
                                redirect("login.php");
                            }
                            else
                            {
                                
                                $decrypted_pass = encrypt_decrypt('decrypt', $db_password);
                                
                                
                                if ( $decrypted_pass === $password && $email==$db_email )
                                {
                                        
                                        $_SESSION['user'] = $db_name;
                                        $_SESSION['userID'] = $db_id;
                                        redirect("index.php");
                                    
                                  
                                    
                                }
                                else
                                {
                                    
                                    set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                    </button>
                                    
                                    </div>");
                                    redirect("login.php");
                                    
                                }
                                
                                
                
                        }
                
        
                    }
            }
            else
            {
                 set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                   <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                   <span aria-hidden='true'>&times;</span>
                   </button>
                    Oopps... No! Username exists
                   </div>");
        redirect("login.php");    
       
            }
                
            
            
       
        }
        
        else
        {
        set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                   <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                   <span aria-hidden='true'>&times;</span>
                   </button>
                   Please fill out all the fields!
                   </div>");
        redirect("login.php");    
       
       
       
        }
    }
   

}
function updateUser()
{
    if(isset($_POST['submit']))
    {
        $userName     =$_POST['userName'];
        $userMobileNo =$_POST['mobileNo'];
        $userAddress  =$_POST['address'];
        $password     =$_POST['password'];
        $email        =$_POST['email'];
        
        if(strlen($password)<4)
        {
            $query ="UPDATE users SET ";
            $query.="userName     ='{$userName}',";
            $query.="userMobileNo ='{$userMobileNo}',";
            $query.="userAddress  ='{$userAddress}',";
            $query.="userEmail    ='{$email}' ";
            $query.="WHERE userName='{$_SESSION['user']}';";
            
            query($query);
            confirm($query);
             
             set_message("<div class='alert alert-success alert-dismissible fade show' role='alert'>
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
  Your details have been saved!
</div>");
             redirect("profile.php");
        }
        else
        {
            
              $encrypted_pass = encrypt_decrypt('encrypt', $password);
            
            $query ="UPDATE users SET ";
            $query.="userName     ='{$userName}',";
            $query.="userMobileNo ='{$userMobileNo}',";
            $query.="userAddress  ='{$userAddress}',";
            $query.="userPassword ='{$encrypted_pass}',";
            $query.="userEmail    ='{$email}'";
            $query.="WHERE userName='{$_SESSION['user']}';";
            query($query);
            confirm($query);
             
             set_message("<div class='alert alert-success alert-dismissible fade show' role='alert'>
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
  You details have been saved!
</div>");
            redirect("profile.php");
        }
    }
}


function registerUser()
{
    global $connection;
    if(isset($_POST['registerUser']))
    {
        $pass1=escape_string($_POST['password1']);
        $pass2=escape_string($_POST['password2']);
        $email=escape_string($_POST['email']);
        $mobileNo=escape_string($_POST['mobileNo']);
        $name=escape_string($_POST['name']);
        $firstname=escape_string($_POST['firstname']);
        $lastname=escape_string($_POST['lastname']);
        $address=escape_string($_POST['address']);
        
       if(strlen($email)>0 && strlen($name)>0)
       {
           
            if (strlen($pass1) < 8) {
                $errors[] = "Password too short!";
                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>Password too short</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
            }

            else if (!preg_match("#[0-9]+#", $pass1)) {
                $errors = "Password must include at least one number!";
                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>{$errors}</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
            }

            else if (!preg_match("#[a-zA-Z]+#", $pass1)) {
                $errors = "Password must include at least one letter!";
                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>{$errors}</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
            }
           
            else
            {
                
            
         
                    if($pass1==$pass2)
                    {
        
      
            
            
           
        $encrypted_pass = encrypt_decrypt('encrypt', $pass1);
  

        
        $query=query("INSERT INTO users(userFirstName,userLastName,userName,userEmail,userPassword,userMobileNo,userAddress) VALUES('{$firstname}','{$lastname}','{$name}','{$email}','{$encrypted_pass}','{$mobileNo}','{$address}')");
        confirm($query);
            
                     
          set_message("<div class='alert alert-success alert-dismissible fade show' role='alert'>
  <strong>Good! Now Login</strong> 
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div>");    
            redirect("login.php");     
        }
                    else
                    {
                            set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>Please confirm your password correctly</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            redirect("register.php");
        }
                
            }
       }
       else
        {
              set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>Please enter all fields</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
        }
     
    }
}
function registerBloodCenter()
{
    global $connection;
    if(isset($_POST['registerCenter']))
    {
        $pass1=escape_string($_POST['centerPassword']);
        $pass2=escape_string($_POST['centerPassword2']);
        $email=escape_string($_POST['centerEmail']);
        $name=escape_string($_POST['centerName']);
        $mobileNo=escape_string($_POST['centerMobileNo']);
        $address=escape_string($_POST['centerAddress']);
        
       if(strlen($email)>0 && strlen($name)>0)
       {
           
            if (strlen($pass1) < 8) {
                $errors[] = "Password too short!";
                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>Password too short</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
            }

            else if (!preg_match("#[0-9]+#", $pass1)) {
                $errors = "Password must include at least one number!";
                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>{$errors}</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
            }

            else if (!preg_match("#[a-zA-Z]+#", $pass1)) {
                $errors = "Password must include at least one letter!";
                set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>{$errors}</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
            }
           
            else
            {
                
                    if($pass1==$pass2)
                    {
        
      
            
            
           
        $encrypted_pass = encrypt_decrypt('encrypt', $pass1);
  

        
        $query=query("INSERT INTO bloodcenters(bloodCenterName,bloodCenterEmail,bloodCenterPassword,bloodCenterMobileNo,bloodCenterAddress) VALUES('{$name}','{$email}','{$encrypted_pass}','{$mobileNo}','{$address}')");
        confirm($query);
            
        if($query!=null)
        {
            $last_id=mysqli_insert_id($connection);
            $q=query("INSERT INTO bloodCapacity(bloodCenterID,bloodCapacity) VALUES('{$last_id}','0')");
            confirm($q);   
        }
         
            
          set_message("<div class='alert alert-success alert-dismissible fade show' role='alert'>
  <strong>Good! Now Login</strong> 
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div>");    
            redirect("login.php");     
        }
                    else
                    {
                        set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                        <strong>Please confirm your password correctly</strong> 
                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                        </button>
                        </div>");
                        redirect("register.php");
                    }
                
            }
       }
       else
        {
              set_message("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
                  <strong>Please enter all fields</strong> 
                  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                    <span aria-hidden='true'>&times;</span>
                  </button>
                </div>");
            
            redirect("register.php");
        }
     
    }
}



function submit_result()
{
    if(isset($_POST['submit']))
    {
        $user           =$_POST['userID'];
        $blood_type     =$_POST['blood_group'];
        $blood_center_id=$_POST['blood_center'];
        $serialNo       =$_POST['serialNo'];
        $donateDate     =$_POST['donateDate'];
        $hepatitisB     =$_POST['hepatitisB'];
        $hepatitisC     =$_POST['hepatitisC'];
        $hiv            =$_POST['hepatitisC'];
        $malaria        =$_POST['malaria'];
        $bloodCount     =$_POST['bloodCount'];
        $bloodSugar     =$_POST['bloodSugar'];
        $cholesterol    =$_POST['cholesterol'];
        $renalProfile   =$_POST['renalProfile'];
        $testComments   =$_POST['testComments'];
        
        
        
        $query=query("INSERT INTO testresults(userID,serialNo,donateDate,bloodType,bloodCenterID,hepatitisB,hepatitisC,hiv,malaria,bloodCount,bloodSugar,cholesterol,renalProfile,testComments,uploadDate) VALUES('{$user}','{$serialNo}','{$donateDate}','{$blood_type}','{$blood_center_id}','{$hepatitisB}','{$hepatitisC}','{$hiv}','{$malaria}','{$bloodCount}','{$bloodSugar}','{$cholesterol}','{$renalProfile}','{$testComments}',now())");
        confirm($query);
        
        set_message("<div class='alert alert-success alert-dismissible fade show' role='alert'>
  <strong>Result Added</strong> You should check in on some of those fields below.
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div>");
        
        redirect("blood_centers.php");
        
    }
}
function add_blood_capacity()
{
    if(isset($_POST['submit']))
    {
       
        $blood_center_id=$_POST['blood_center'];
        $blood_capacity =$_POST['blood_capacity'];
        
        
        
        $query=query("UPDATE bloodcapacity SET
        bloodcapacity=$blood_capacity
        WHERE bloodCenterID='{$blood_center_id}'");
        
        set_message("<div class='alert alert-success alert-dismissible fade show' role='alert'>
  <strong>Blood Capacity Update</strong> You should check in on some of those fields below.
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div>");
        
        redirect("blood_capacity.php");
        
    }
}

function update_result()
{
    
    if(isset($_POST['submit']))
    {
        
        $blood_type     =$_POST['blood_group'];
        $blood_center_id=$_POST['blood_center'];
        $hepatitisB     =$_POST['hepatitisB'];
        $hepatitisC     =$_POST['hepatitisC'];
        $hiv            =$_POST['hepatitisC'];
        $malaria        =$_POST['malaria'];
        $bloodCount     =$_POST['bloodCount'];
        $bloodSugar     =$_POST['bloodSugar'];
        $cholesterol    =$_POST['cholesterol'];
        $renalProfile   =$_POST['renalProfile'];
        $testComments   =$_POST['testComments'];
        
        $query ="UPDATE testresults SET ";
        $query.="bloodType='{$blood_type}',";
        $query.="bloodCenterID='{$blood_center_id}',";
        $query.="hepatitisB='{$hepatitisB}',";
        $query.="hepatitisC='{$hepatitisC}',";
        $query.="hiv='{$hiv}',";
        $query.="malaria='{$malaria}',";
        $query.="bloodCount='{$bloodCount}',";
        $query.="bloodSugar='{$bloodSugar}',";
        $query.="cholesterol='{$cholesterol}',";
        $query.="renalProfile='{$renalProfile}',";
        $query.="testComments='{$testComments}' ";
        $query.="WHERE testID='{$_GET['id']}'";
        
        $q=query($query);
        confirm($q);
        set_message("<div class='alert alert-info alert-dismissible fade show' role='alert'>
  <strong>Result Updated</strong> 
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div>");
    }
    
    
}
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}






?>
