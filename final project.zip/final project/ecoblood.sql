-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 5, 2022 at 02:44 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Metamaywa blood center`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloodcapacity`
--

CREATE TABLE IF NOT EXISTS `bloodcapacity` (
  `bloodCapacityID` int(11) NOT NULL,
  `bloodCenterID` int(11) NOT NULL,
  `bloodCapacity` varchar(255) NOT NULL,
  `aPositive` varchar(255) NOT NULL DEFAULT '0',
  `aNegative` varchar(255) NOT NULL DEFAULT '0',
  `oPositive` varchar(255) NOT NULL DEFAULT '0',
  `oNegative` varchar(255) NOT NULL DEFAULT '0',
  `bPositive` varchar(255) NOT NULL DEFAULT '0',
  `bNegative` varchar(255) NOT NULL DEFAULT '0',
  `abPositive` varchar(255) NOT NULL DEFAULT '0',
  `abNegative` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodcapacity`
--

INSERT INTO `bloodcapacity` (`bloodCapacityID`, `bloodCenterID`, `bloodCapacity`, `aPositive`, `aNegative`, `oPositive`, `oNegative`, `bPositive`, `bNegative`, `abPositive`, `abNegative`) VALUES
(17, 20, '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(18, 21, '0', '0', '0', '0', '0', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `bloodcenters`
--

CREATE TABLE IF NOT EXISTS `bloodcenters` (
  `bloodCenterID` int(11) NOT NULL,
  `bloodCenterName` varchar(255) NOT NULL,
  `bloodCenterPassword` varchar(255) NOT NULL,
  `bloodCenterEmail` varchar(255) NOT NULL,
  `bloodCenterUserRole` varchar(255) NOT NULL DEFAULT 'user',
  `bloodCenterMobileNo` varchar(255) NOT NULL,
  `bloodCenterAddress` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodcenters`
--

INSERT INTO `bloodcenters` (`bloodCenterID`, `bloodCenterName`, `bloodCenterPassword`, `bloodCenterEmail`, `bloodCenterUserRole`, `bloodCenterMobileNo`, `bloodCenterAddress`) VALUES
(20, 'admin', 'SGpSVVBmQ2pra2xtS0F0SEJpRnM4UT09', 'admin@d.com', 'admin', '0723123123', 'Admin'),
(21, 'St Florence', 'SGpSVVBmQ2pra2xtS0F0SEJpRnM4UT09', 'florence@gmail.com', 'user', '07280712321', 'Florence');

-- --------------------------------------------------------

--
-- Table structure for table `testresults`
--

CREATE TABLE IF NOT EXISTS `testresults` (
  `testID` int(11) NOT NULL,
  `serialNo` varchar(255) NOT NULL,
  `userID` varchar(255) NOT NULL,
  `bloodType` varchar(255) NOT NULL,
  `testComments` text NOT NULL,
  `bloodCenterID` int(11) NOT NULL,
  `hepatitisB` varchar(255) NOT NULL,
  `hepatitisC` varchar(255) NOT NULL,
  `hiv` varchar(255) NOT NULL,
  `malaria` varchar(255) NOT NULL,
  `bloodCount` varchar(255) NOT NULL,
  `bloodSugar` varchar(255) NOT NULL,
  `cholesterol` varchar(255) NOT NULL,
  `renalProfile` varchar(255) NOT NULL,
  `donateDate` date NOT NULL,
  `uploadDate` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userID` int(11) NOT NULL,
  `userFirstName` varchar(255) NOT NULL,
  `userLastName` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `userAddress` varchar(255) NOT NULL,
  `userMobileNo` varchar(255) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userPassword` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `userFirstName`, `userLastName`, `userName`, `userAddress`, `userMobileNo`, `userEmail`, `userPassword`) VALUES
(2, 'Dacre', 'Montgomery', 'Dacre', 'asdasd', '12312312', 'dax@gmail.com', 'bjNxVEdickhtSHkyMWd0NTFCODBBdz09'),
(3, 'Jaime', 'Lannister', '', 'Casterly Rock', '0712312312', 'jaime@gmail.com', 'SGpSVVBmQ2pra2xtS0F0SEJpRnM4UT09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloodcapacity`
--
ALTER TABLE `bloodcapacity`
  ADD PRIMARY KEY (`bloodCapacityID`);

--
-- Indexes for table `bloodcenters`
--
ALTER TABLE `bloodcenters`
  ADD PRIMARY KEY (`bloodCenterID`);

--
-- Indexes for table `testresults`
--
ALTER TABLE `testresults`
  ADD PRIMARY KEY (`testID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bloodcapacity`
--
ALTER TABLE `bloodcapacity`
  MODIFY `bloodCapacityID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `bloodcenters`
--
ALTER TABLE `bloodcenters`
  MODIFY `bloodCenterID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `testresults`
--
ALTER TABLE `testresults`
  MODIFY `testID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
