<?php include ("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> METAMAYWA HEALTH BLOOD CENTRE  Test Results</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
     <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

   <?php include("includes/navigation.php");   ?>

  <?php


if(isset($_SESSION['user']))
{
    $query = query("SELECT * FROM users WHERE userName ='{$_SESSION['user']}' ");
                confirm($query);
                while($row=fetch_array($query))
                {
                    $username=$row['userName'];
                    $userID=$row['userID'];
                    
                    $uquery = query("SELECT * FROM testresults WHERE userID ='{$userID}' ");
                    confirm($uquery);
                    while($row=fetch_array($uquery))
                    {
                        
                        $bloodType   =$row['bloodType'];
                        $userID    =$row['userID'];
                        $bloodCenterID=$row['bloodCenterID'];
                        $hepatitisC  =$row['hepatitisC'];
                        $hepatitisB  =$row['hepatitisB'];
                        $hiv         =$row['hiv'];
                        $malaria     =$row['malaria'];
                        $bloodCount  =$row['bloodCount'];
                        $bloodSugar  =$row['bloodSugar'];
                        $cholesterol =$row['cholesterol'];
                        $renalProfile=$row['renalProfile'];
                        $uploadDate  =$row['uploadDate'];
                        
                        
                                $query = query("SELECT * FROM bloodcenters WHERE bloodCenterID ='{$bloodCenterID}' ");
                                  confirm($query);
                                  while($row=fetch_array($query))
                                  {
                                    
                                      $bloodCenterName=$row['bloodCenterName'];
                                     
                                      
                                  }
                        
                    }
                    
                    
                    
                    
                }
    
}


  
          


?>

    <body>

        <div class="content-wrapper">
            <div class="container">


                <!-- Appointments-->
                <div class="row" style="margin-top:40px; margin-bottom:140px; ">

                    <div class="col-md-12">
                        <?php display_message(); ?>
                        <div class="card text-black  mb-3">
                            <div class="card-header bg-primary text-center text-white"><i class="fa fa-table"></i> Blood Group : </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th scope="col">Blood Center</th>
                                            <th scope="col">Hepatitis B</th>
                                            <th scope="col">Hepatitis C</th>
                                            <th scope="col">HIV</th>
                                            <th scope="col">Malaria</th>
                                            <th scope="col">Blood Count</th>
                                            <th scope="col">Blood Sugar</th>
                                            <th scope="col">Cholesterol</th>
                                            <th scope="col">Renal Profile</th>
                                            <th scope="col">Upload Date</th>
                                           

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                $query = query("SELECT * FROM testresults
                INNER JOIN users ON users.userID=testresults.userID
                INNER JOIN bloodcenters ON bloodcenters.bloodCenterID=testresults.bloodCenterID
                WHERE testresults.userID={$userID}");
                confirm($query);
                while($row=fetch_array($query))
                {
                    $date=$row['uploadDate'];
                    $timestamp = strtotime($date);
                    $formattedDate = date('F d, Y', $timestamp);
                     $bloodCenterID=$row['bloodCenterID'];
                    
                    
                        $hepatitisC  =$row['hepatitisC'];
                        $hepatitisB  =$row['hepatitisB'];
                        $hiv         =$row['hiv'];
                        $malaria     =$row['malaria'];
                        $bloodCount  =$row['bloodCount'];
                        $bloodSugar  =$row['bloodSugar'];
                        $cholesterol =$row['cholesterol'];
                        $renalProfile=$row['renalProfile'];
                        $uploadDate  =$row['uploadDate'];
                    
                    
                     $query = query("SELECT * FROM bloodcenters WHERE bloodCenterID ='{$bloodCenterID}' ");
                                  confirm($query);
                                  while($row=fetch_array($query))
                                  {
                                    
                                      $bloodCenterName=$row['bloodCenterName'];
                                     
                                      
                                  }
                    
                        
                   
                    
                    echo "
                      <tr>
                                            <th scope='row'>{$bloodCenterName}</th>
                                            <td>{$hepatitisB}</td>
                                            <td>{$hepatitisC}</td>
                                            <td>{$hiv}</td>
                                            <td>{$malaria}</td>
                                            <td>{$bloodCount}</td>
                                            <td>{$bloodSugar}</td>
                                            <td>{$cholesterol}</td>
                                            <td>{$renalProfile}</td>
                                            <td>{$formattedDate}</td>
                                            
                                           
                                        </tr>
                    ";
                    
                    
                
         
                
                }
                                        
                                        
                                        ?>



                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>


                </div>


            </div>
            <div id="modal_edit" class="modal fade" style="font-weight: normal;">
                <div class="modal-dialog">
                    <div class="modal-content">

                    </div>
                </div>
            </div>

            <!-- /.container -->

            <script>
                $('#commentModal').on('show.bs.modal', function(event) {
                    var button = $(event.relatedTarget) // Button that triggered the modal
                    var recipient = button.data('whatever') // Extract info from data-* attributes
                    // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
                    // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
                    var modal = $(this)
                    modal.find('.modal-title').text('New message to ' + recipient)
                    modal.find('.modal-body input').val(recipient)
                })

            </script>
          
            <script>
                $('.modalButton').click(function() {
                    var appointmentID = $(this).attr('data-appointment-id');
                    $.ajax({
                        url: "ajax_modal_comment.php?appointmentID=" + appointmentID,
                        cache: false,
                        success: function(result) {
                            $(".modal-content").html(result);
                        }
                    });
                });

            </script>
           
    <!-- Footer -->
    <footer class="py-5 bg-dark" style="margin-top:300px;"
     >
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; METAMAYWA HALTH BLOOD CENTRE 2022</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
