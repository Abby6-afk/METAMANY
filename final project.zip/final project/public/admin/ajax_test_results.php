<?php
include "../../resources/config.php";
$testID = $_GET['id'];


  $query=query("SELECT * FROM testresults WHERE testID='{$testID}'");
                    confirm($query);
                    while($row = fetch_array($query)) {
                        
                        $bloodType   =$row['bloodType'];
                        $bloodCenterID=$row['bloodCenterID'];
                        $hepatiitsC  =$row['hepatitisC'];
                        $hepatiitsB  =$row['hepatitisB'];
                        $hiv         =$row['hiv'];
                        $malaria     =$row['malaria'];
                        $bloodCount  =$row['bloodCount'];
                        $bloodSugar  =$row['bloodSugar'];
                        $cholesterol =$row['cholesterol'];
                        $renalProfile=$row['renalProfile'];
                        $uploadDate  =$row['uploadDate'];
                        
                        
                         $query=query("SELECT * FROM users WHERE bloodCenterID='{$bloodCenterID}'");
                    confirm($query);
                    while($row = fetch_array($query)) {
                        $name=$row['bloodCenterName'];
                    
                    }
                    }





?>
    <div class="modal-header">
        <h5 class="modal-title">Test Results for Blood Type

        </h5>
    </div>

    <div class="modal-body col-md-offset-3">

        <div class="row">
            <div class="col-lg-6"><label for="">Blood Type  </label></div>: <?php echo $bloodType; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Blood Center  </label></div>: <?php echo $name; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Hepatitis B  </label></div>: <?php echo $hepatiitsB; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Hepatitis C  </label></div>: <?php echo $hepatiitsC; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">HIV / AIDS  </label></div>: <?php echo $hiv; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Malaria  </label></div>: <?php echo $malaria; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Blood Count </label></div>: <?php echo $bloodCount; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Blood Sugar</label></div>: <?php echo $bloodSugar; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Cholesterol Levels</label></div>: <?php echo $cholesterol; ?>

        </div>
        <div class="row">
            <div class="col-lg-6"><label for="">Renal Profile</label></div>: <?php echo $renalProfile; ?>

        </div>
        




    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      
    </div>


    <?php


?>
