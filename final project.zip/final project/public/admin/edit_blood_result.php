<?php include ("../../resources/config.php");

if(isset($_GET['id']))
{
    $id=$_GET['id'];
    $query = query("SELECT * FROM testresults WHERE testID='{$id}'");
    confirm($query);
    while($row=fetch_array($query))
        {
        $blood_type     =$row['bloodType'];
        $userID         =$row['userID'];
        $serialNo       =$row['serialNo'];
        $blood_center_id=$row['bloodCenterID'];
        $hepatitisB     =$row['hepatitisB'];
        $hepatitisC     =$row['hepatitisC'];
        $hiv            =$row['hepatitisC'];
        $malaria        =$row['malaria'];
        $bloodCount     =$row['bloodCount'];
        $bloodSugar     =$row['bloodSugar'];
        $cholesterol    =$row['cholesterol'];
        $renalProfile   =$row['renalProfile'];
        $testComments   =$row['testComments'];
    }
        
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>METAMAYWA HEALTH CENTER | Edit Blood Result</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include ("includes/navigation.php"); ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Edit Blood Result</li>
      </ol>
     <div class="row">
              
                <div class="col-md-12" style="margin-top:20px">
                   <?php update_result();   display_message(); ?>
                    <div class="card text-black  mb-3">
                        <?php
                    $query=query("SELECT * FROM users WHERE userID='{$userID}'");
                    confirm($query); 
                    while($row = fetch_array($query)) {
                       
                    
                    $username =$row['userName'];
                    $userID =$row['userID'];
                        
                        
                    $query=query("SELECT * FROM bloodcenters WHERE bloodCenterName!='admin' AND bloodCenterID='{$blood_center_id}'");
                    confirm($query); 
                    while($row = fetch_array($query)) {
                       
                    $email=$row['bloodCenterEmail'];
                    $id   =$row['bloodCenterID'];
                    $name =$row['bloodCenterName'];
                        
                        
                   
                    
                                    
                        
                    echo "<div class='card-header bg-danger text-center text-white'>{$username}'s results    Serial No: {$serialNo} </div>";
                    echo "<div class='card-header bg-info text-center text-white'>Blood Group : {$blood_type} Blood Center:   {$name}                  </div>";
                    
                    }
                        
                }
                                
                                
                            ?>    
                     
                        <div class="card-body">
                            <form method="post">
                        
                    
                       
                  
                        
                        <div class="row">
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>Hepatitis B</strong></label>
                                <input type="text" name="hepatitisB" value="<?php echo $hepatitisB; ?>" class="form-control">
                            </div>
                            </div>
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>Hepatitis C</strong></label>
                                <input type="text" name="hepatitisC" value="<?php echo $hepatitisC; ?>" class="form-control">
                            </div>
                            </div>
                        </div>
                          <div class="row">
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>HIV</strong></label>
                                <input type="text" name="hiv" value="<?php echo $hiv; ?>" class="form-control">
                            </div>
                            </div>
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>Malaria</strong></label>
                                <input type="text" name="malaria" value="<?php echo $malaria; ?>" class="form-control">
                            </div>
                            </div>
                        </div>
                         
                          <div class="row">
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>Blood Count</strong></label>
                                <input type="text" name="bloodCount" value="<?php echo $bloodCount; ?>" class="form-control">
                            </div>
                            </div>
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>Blood Sugar</strong></label>
                                <input type="text" name="bloodSugar" value="<?php echo $bloodSugar; ?>" class="form-control">
                            </div>
                            </div>
                        </div>
                          <div class="row">
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>Cholesterol</strong></label>
                                <input type="text" name="cholesterol" value="<?php echo $cholesterol; ?>" class="form-control">
                            </div>
                            </div>
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for=""><strong>Renal Profile</strong></label>
                                <input type="text" name="renalProfile" value="<?php echo $renalProfile; ?>" class="form-control">
                            </div>
                            </div>
                        </div>
                          <div class="row">
                             <div class="col-lg-12">
                                  <div class="form-group"><label for=""></label><strong>Result Comments</strong><textarea class="form-control" name="testComments" id="" cols="30" rows="10"><?php echo $testComments; ?></textarea></div>
                             </div>
                             
                          </div>
                          
                          <div class="row">
                              <div class="col-lg-12"><input type="submit" value="Update" name="submit" class="btn btn-danger form-control"></div>
                          </div>
                          
                           
                         
                            
                       

                    </form>
                          </div>
                            <div class="">
                   
                 
                            </div>
                        </div>
                    </div>
                </div>


            </div>


        </div>

    
    </div>
   <?php include ("includes/footer.php"); ?>
