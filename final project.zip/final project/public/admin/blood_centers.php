<?php include ("../../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title> METAMAYWA HEALTH BLOOD CENTRE | Blood Centers</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include ("includes/navigation.php"); ?>
  <div class="content-wrapper">
    <div class="container-fluid">
        <?php display_message(); ?>
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blood Centers</li>
      </ol>
   
   
        <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header bg-primary text-white text-center">
          <i class="fa fa-table text-white"></i> Blood Centers</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Blood Center</th>
                  <th>Email</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Blood Center</th>
                  <th>Email</th>
                  <th>Actions</th>
                </tr>
              </tfoot>
              <tbody>
               
                <?php
                    $query=query("SELECT * FROM bloodcenters WHERE bloodCenterName!='admin'");
                    confirm($query);
                    while($row = fetch_array($query)) {
                       
                    $email=$row['bloodCenterEmail'];
                    $id   =$row['bloodCenterID'];
                    $name =$row['bloodCenterName'];
                     
                    $row="
                     <tr>
                    <td>{$name}</td>
                    <td>{$email}</td>
                    <td><a href='test_results.php?id={$id}' class='btn btn-info'><i class='fa fa-align-left'></i></a></td>
                    </tr>
                    ";        
                        
                    echo $row;
                    }
                    
                    
                    
                    ?>
                
                 
                
            
              
              </tbody>
            </table>
          </div>
        </div>
     
      </div>
    
    
    </div>
   <?php include ("includes/footer.php"); ?>
