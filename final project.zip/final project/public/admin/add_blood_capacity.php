<?php include ("../../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>METAMAYWA HEALTH CENTER | Add Blood Result</title>
    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    
    <link href="css/bootstrap-datepicker.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/datepicker.css" rel="stylesheet">
    <!-- Include Date Range Picker -->

<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

   
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
    <!-- Navigation-->
    <?php include ("includes/navigation.php"); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Add Blood Capacity</li>
            </ol>
            <div class="row">

                <div class="col-md-12" style="margin-top:20px">
                    <?php add_blood_capacity(); ?>
                    <div class="card text-black  mb-3">
                        <div class="card-header bg-danger text-center text-white">Add Blood Capacity</div>
                        <div class="card-body">
                            <form method="post">
                            
                                <div class="row">
                              
                                    <div class="col-lg-12"><label for=""><strong>Blood Centers</strong></label>
                                        <select name="blood_center" class="form-control" id="">
                            <?php
                            $query=query("SELECT * FROM bloodcenters WHERE bloodCenterName!='admin'");
                    confirm($query); 
                    while($row = fetch_array($query)) {
                       
                    $email=$row['bloodCenterEmail'];
                    $id   =$row['bloodCenterID'];
                    $name =$row['bloodCenterName'];
                        
                        
                    echo "<option value='{$id}'>{$name}</option>";
                    
                    }
                                
                                
                            ?>    
                        </select>

                                    </div>
                                </div>

                               
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label for=""><strong>Blood Capacity</strong></label>
                                            <input type="text" name="blood_capacity" placeholder="Enter Blood Capacity" class="form-control">
                                        </div>
                                    </div>
                                   
                                </div>
                               
                                <div class="row">
                                    <div class="col-lg-12"><input type="submit" value="Add" name="submit" class="btn btn-danger form-control"></div>
                                </div>






                            </form>
                        </div>
                        <div class="">


                        </div>
                    </div>
                </div>
            </div>


        </div>


    </div>


    </div>

    <?php include ("includes/footer.php"); ?>
 <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
 <script type="text/javascript">
$(function() {
    $('input[name="donateDate"]').daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
        locale: {
            format: 'YYYY-MM-DD'
        }
    }, 
    function(start, end, label) {
        var years = moment().diff(start, 'years');
      
    });
});
</script>
