<?php include ("../../resources/config.php");


if(isset($_GET['id']))
{
    $centerID=$_GET['id'];
    
    
    $query=query("SELECT bloodCenterName FROM bloodcenters WHERE bloodCenterID='{$centerID}'");
    confirm($query);
    while($row=fetch_array($query))
    {
        $centerName=$row['bloodCenterName'];
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>METAMAYWA HEALTH CENTER | Test Results</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include ("includes/navigation.php"); ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Test Results</li>
      </ol>
   
   
        <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header bg-info text-white text-center">
         
          <i class="fa fa-table text-white"></i> <?php echo $centerName; ?> Test Results</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Blood ID</th>
                  <th>User</th>
                  <th>Blood Type</th>
                  <th>Date Donated</th>
                  <th>Date Uploaded</th>
                  <th>Actions</th>
                  
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Blood ID</th>
                  <th>User</th>
                  <th>Blood Type</th>
                  <th>Date Donated</th>
                  <th>Date Uploaded</th>
                  <th>Actions</th>
                </tr>
              </tfoot>
              <tbody>
               
                <?php
                    $query=query("SELECT * FROM testresults
                    INNER JOIN users ON users.userID=testresults.userID
                    INNER JOIN bloodcenters ON bloodcenters.bloodCenterID=testresults.bloodCenterID
                    WHERE testresults.bloodCenterID='{$centerID}'");
                    confirm($query);
                    while($row = fetch_array($query)) {
                       
                 
                    $date =$row['uploadDate'];
                    $donatedate =$row['donateDate'];
                    $firstname =$row['userFirstName'];
                    $lastname =$row['userLastName'];
                    $type =$row['bloodType'];
                    $id   =$row['testID'];
                        
                
                    $timestamp = strtotime($date);
                    $formattedDate = date('F d, Y', $timestamp);
                        
                    
                    $donDate = date('F d, Y', strtotime($donatedate));
                     
                        
                    $rowAdmin="
                     <tr>
                     <td>{$id}</td>
                     <td>{$firstname} {$lastname}</td>
                    <td>{$type}</td>
                    <td>{$donDate}</td>
                    <td>{$formattedDate}</td>
                    <td><a href='#modal_edit' class='btn btn-info modalButton' data-test-id='{$id}' data-toggle='modal' data-target='#modal_edit' data-popup='tooltip' title='View' data-container='body'>
                      <i class='fa fa-align-left'></i></a> <a href='edit_blood_result.php?id={$id}' class='btn btn-warning'   data-popup='tooltip' title='Edit' data->
                      <i class='fa fa-edit'></i></a></td>
                    </tr>
                    ";
                        
                        
                 $row="
                     <tr>
                     <td>{$id}</td>
                     <td>{$firstname} {$lastname}</td>
                    <td>{$type}</td>
                    <td>{$donDate}</td>
                    <td>{$formattedDate}</td>
                    <td><a href='#modal_edit' class='btn btn-info modalButton' data-test-id='{$id}' data-toggle='modal' data-target='#modal_edit' data-popup='tooltip' title='View' data-container='body'>
                     </td>
                    </tr>
                    ";        
                        
                    if(!isset($_SESSION['admin']))
                    {
                        echo $row;
                    }
                    else
                    {
                        echo $rowAdmin;
                    }
                        
                        
                    }
                    
                    
                    
                    ?>
                
                 
                
            
              
              </tbody>
            </table>
          </div>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
    
    
    </div>
      <div id="modal_edit" class="modal fade" style="font-weight: normal;">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">

                    </div>
                </div>
            </div>
   <?php include ("includes/footer.php"); ?>
    <script>
                $('.modalButton').click(function() {
                    var id = $(this).attr('data-test-id');
                    $.ajax({
                        url: "ajax_test_results.php?id=" + id,
                        cache: false,
                        success: function(result) {
                            $(".modal-content").html(result);
                        }
                    });
                });

            </script>
