<?php require_once 'config.php';     ?>
<?php



/* Basic Functions */
function row_count($result)
{
    return mysqli_num_rows($result);
}

function clean($string)
{
    return htmlentities($string);
}

function redirect($location)
{
return header("Location: $location ");
}

function query($sql)
{
    
global $connection;
return mysqli_query($connection, $sql);
}

function confirm($result)
{
global $connection;
if(!$result) {
die("QUERY FAILED " . mysqli_error($connection));
	}
}


function fetch_array($result){
    
return mysqli_fetch_array($result);
}

function set_message($msg){
if(!empty($msg)) {
$_SESSION['message'] = $msg;
} else {
$msg = "";
    }
}
function display_message() {
    if(isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }
}



/****************************/
function login()
{
    if (isset($_POST['login'])){
        
        $email         = $_POST["Email"];
        $password      = $_POST["Password"];
        
        
        $select_query=query("SELECT * FROM users WHERE email='{$email}' && password='{$password}'");
        confirm($select_query);
        while($row=fetch_array($select_query))
        {
            $db_email=$row['email'];
            $db_password=$row['password'];
            $db_role=$row['user_role'];
            $db_id=$row['id'];
        }
        if(row_count($select_query)==0)
        {
            set_message("Invalid Email or Password");
            display_message();
            
//            redirect("login.php");
        }
        else if($email==$db_email && $password==$db_password && $db_role=='user')
        {
            $_SESSION['email'] = $db_email;
            $_SESSION['id'] = $db_id;

            redirect("admin/index.php");
        }
        else if($email==$db_email && $password==$db_password && $db_role=='admin')
        {
            $_SESSION['admin_email'] = $db_email;
            $_SESSION['admin_id'] = $db_id;
            redirect("admin/index.php");
        }
      
    
    
        

   }
    
}

function register()
{
    if (isset($_POST['register'])){
      
    
    $email         = $_POST["Email"];
    $facility_name = $_POST["Facility_name"];
    $password      = $_POST["Password"];
   
    $sql ="INSERT INTO users( email, Facility_name,password) VALUES ('$email',' $facility_name', '$password')";
    $insert_query=query($sql);

    confirm($insert_query); 
    redirect("login.php");   

}
    
        
}
function add_blood_results()
{
    if (isset($_POST['addBtn'])){
      
    
    $results         = $_POST["results"];
    $bloodCenter     = $_POST["bloodCenter"];

   
    $sql ="INSERT INTO testresults( testResults,bloodCenter) VALUES ('{$results}','{$bloodCenter}')";
    $insert_query=query($sql);

    confirm($insert_query); 
       
}
}
function update_blood_results()
{
    if(isset($_POST['update']))
    {
    $results         = $_POST["results"];
    $bloodCenter     = $_POST["bloodCenter"];
        
        
        
    }
}





































?>
