<?php include ("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> METAMAYWA HEALTH BLOOD CENTRE Profile</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
     <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

   <?php include("includes/navigation.php");   ?>

  <?php

if(isset($_SESSION['user']))
{
    $query = query("SELECT * FROM users WHERE userID ='{$_SESSION['userID']}' ");
                confirm($query);
                while($row=fetch_array($query))
                {
                    $username=$row['userName'];
                    $firstname=$row['userFirstName'];
                    $lastname=$row['userLastName'];
                    $userMobileNo=$row['userMobileNo'];
                    $userEmail=$row['userEmail'];
                    $userAddress=$row['userAddress'];
                    $password=$row['userPassword'];
                    
                }
    
}
  
          


?>

    <body>

        <div class="content-wrapper">
            <div class="container">


               <!-- Appointments-->
                <div class="row">

                    <div class="col-md-12" style="margin-top:20px">
                        <?php display_message(); ?>
                        <div class="card text-black  mb-3">
                            <div class="card-header bg-primary text-center text-white"><i class="fa fa-user"></i> Profile</div>
                            <div class="card-body">
                                <div class="card-title text-center" style="font-size:30px;"><strong><?php echo "{$firstname} {$lastname}"; ?></strong></div>
                                <div class="">
                                    <form method="post" action="" class="">
                                        <?php updateUser(); ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label class="" for="username">Username</label>
                                                    <input name="userName" class="form-control" type="text" value="<?php echo $username ?>" placeholder="Enter New Username"  disabled/>
                                                </div>
                                                <div class="form-group ">
                                                    <label class="" for="email">Email</label>
                                                    <input name="email" class="form-control" type="text" value="<?php echo $userEmail ?>" placeholder="Enter Email" />

                                                </div>
                                                <div class="form-group ">
                                                    <label class="" for="email">Password</label>
                                                    <input name="password" class="form-control" type="password" placeholder="Enter New Password" />

                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label class="" for="mobile">User Mobile</label>
                                                    <input name="mobileNo" class="form-control" type="text" value="<?php echo $userMobileNo ?>" placeholder="Enter Mobile Name" />

                                                </div>
                                                <div class="form-group ">
                                                    <label class="" for="address">User Address</label>
                                                    <input name="address" class="form-control" type="text" value="<?php echo $userAddress ?>" placeholder="Enter Address" />

                                                </div>

                                            




                                            </div>
                                        </div>
                                        <div class="row">

                                            <input type="submit" name="submit" value="Save Details" class="form-control btn btn-primary" />

                                        </div>


                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>





                </div>
            </div>

            <!-- /.container -->

            <script>
                $('#commentModal').on('show.bs.modal', function(event) {
                    var button = $(event.relatedTarget) // Button that triggered the modal
                    var recipient = button.data('whatever') // Extract info from data-* attributes
                    // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
                    // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
                    var modal = $(this)
                    modal.find('.modal-title').text('New message to ' + recipient)
                    modal.find('.modal-body input').val(recipient)
                })

            </script>
          
            <script>
                $('.modalButton').click(function() {
                    var appointmentID = $(this).attr('data-appointment-id');
                    $.ajax({
                        url: "ajax_modal_comment.php?appointmentID=" + appointmentID,
                        cache: false,
                        success: function(result) {
                            $(".modal-content").html(result);
                        }
                    });
                });

            </script>
           
    <!-- Footer -->
    <footer class="py-5 bg-dark" style="margin-top:300px;"
     >
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; METAMAYWA HEALTH BLOOD CENTRE 2022</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
