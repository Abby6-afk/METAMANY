<?php include ("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>METAMAYWA HEALTH CENTER | Register</title>
    <!-- Bootstrap core CSS-->
    <link href="admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="admin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->

    <link href="admin/css/style.css" rel="stylesheet">
</head>

<body class="bg-dark">
    <div class="container">
        <div class="row" style="margin-bottom:100px;">
            <div class="card card-register mx-auto mt-5">

                <div class="card-header">Register</div>
                <?php display_message();?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-md-offset-3">
                            <div class="panel panel-login">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-6">
                                            <a href="#" style="margin-left:30px;" class="active" id="login-form-link">Register as Blood Center</a>
                                        </div>
                                        <div class="col-xs-6">
                                            <a href="#" style="margin-left:100px;" id="register-form-link">Register as User</a>
                                        </div>
                                    </div>
                                    <hr>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <form id="login-form" action="" role="form" style="display:block;" method="post">
                                                <?php registerBloodCenter(); ?>
                                                <div class="form-group">
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <label for="exampleInputName">Blood Center Name</label>
                                                            <input class="form-control" name="centerName" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter name">
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Email address</label>
                                                    <input class="form-control" id="exampleInputEmail1" type="email" name="centerEmail" aria-describedby="emailHelp" placeholder="Enter email">
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputEmail2">Address</label>
                                                    <input class="form-control" id="exampleInputEmail1" type="text" name="centerAddress" placeholder="Enter Address">
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputEmail4">Mobile No</label>
                                                    <input class="form-control" id="exampleInputEmail3" type="text" name="centerMobileNo" placeholder="Enter Mobile No">
                                                </div>
                                                <div class="form-group">
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <label for="exampleInputPassword1">Password</label>
                                                            <input class="form-control" id="exampleInputPassword1" type="password" name="centerPassword" placeholder="Password">
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label for="exampleConfirmPassword">Confirm password</label>
                                                            <input class="form-control" id="exampleConfirmPassword" type="password" name="centerPassword2" placeholder="Confirm password">
                                                        </div>
                                                    </div>
                                                </div>
                                                <input class="btn btn-primary btn-block" name="registerCenter" type="submit" value="Register" />
                                            </form>



                                            <form id="register-form" action="" role="form" style="display:block;" method="post">
                                                <?php registerUser(); ?>
                                                <div class="form-group">
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <label for="exampleInputName">User Name</label>
                                                            <input class="form-control" name="name" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter username">
                                                        </div>

                                                    </div>
                                                </div>
                                                 <div class="form-group">
                                                    <label for="exampleInputEmail5">First Name</label>
                                                    <input class="form-control" id="exampleInputEmail1" type="text" name="firstname"  placeholder="Enter First name">
                                                </div>
                                                <div class="form-group">
                                                    <label for="exampleInputEmail5">Last Name</label>
                                                    <input class="form-control" id="exampleInputEmail1" type="text" name="lastname"  placeholder="Enter Last name">
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">Email address</label>
                                                    <input class="form-control" id="exampleInputEmail1" type="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                                                </div>
                                                <div class="form-group">
                                                    <label for="example2">Address</label>
                                                    <input class="form-control" id="exampleInputEmail1" type="text" name="address" aria-describedby="emailHelp" placeholder="Enter Address">
                                                </div>
                                                <div class="form-group">
                                                    <label for="example2">Mobile No</label>
                                                    <input class="form-control" id="exampleInputEmail2" type="text" name="mobileNo" placeholder="Enter Mobile no">
                                                </div>
                                                <div class="form-group">
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <label for="exampleInputPassword1">Password</label>
                                                            <input class="form-control" id="exampleInputPassword1" type="password" name="password1" placeholder="Password">
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label for="exampleConfirmPassword">Confirm password</label>
                                                            <input class="form-control" id="exampleConfirmPassword" type="password" name="password2" placeholder="Confirm password">
                                                        </div>
                                                    </div>
                                                </div>
                                                <input class="btn btn-primary btn-block" name="registerUser" type="submit" value="Register" />
                                            </form>
                                            <div class="text-center">
                                                <a class="d-block small mt-3" href="login.php">Login Page</a>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>





                </div>
            </div>
            <!-- Bootstrap core JavaScript-->
            <script src="admin/vendor/jquery/jquery.min.js"></script>
            <script src="admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
            <!-- Core plugin JavaScript-->
            <script src="admin/vendor/jquery-easing/jquery.easing.min.js"></script>

            <script>
                $(function() {

                    $('#login-form-link').click(function(e) {
                        $("#login-form").delay(100).fadeIn(100);
                        $("#register-form").fadeOut(100);
                        $('#register-form-link').removeClass('active');
                        $(this).addClass('active');
                        e.preventDefault();
                    });
                    $('#register-form-link').click(function(e) {
                        $("#register-form").delay(100).fadeIn(100);
                        $("#login-form").fadeOut(100);
                        $('#login-form-link').removeClass('active');
                        $(this).addClass('active');
                        e.preventDefault();
                    });

                });

            </script>
</body>

</html>
