<?php include ("../resources/config.php"); ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> METAMAYWA HEALTH BLOOD CENTRE </title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
     <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

   <?php include("includes/navigation.php");   ?>

    <header>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <!-- Slide One - Set the background image for this slide in the line below -->
          <div class="carousel-item active" style="background-image: url('Admin/images/pro.jpg.jpg')">
            <img src="pro.jpg" alt="">
            <div class="carousel-caption d-none d-md-block">
             
            </div>
          </div>
          <!-- Slide Two - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('Admin/images/pro.jpg')">
            <div class="carousel-caption d-none d-md-block">
             
            </div>
          </div>
          <!-- Slide Three - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('Admin/images/project.jpg')">
            <div class="carousel-caption d-none d-md-block">
              
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </header>

   

      <!-- Portfolio Section -->
      <br> </br>
      <h2>BLOOD BANK CENTRES</h2>
      <br> </br>

      <div class="row">
        <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <a href="#"><img class="card-img-top" src="Admin/images/nai.jpg" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <a href="#">KEROKA</a>
              </h4>
              <p class="card-text">
              Cell phone No: +254 716 773 904
              Hospital Road, Kenyatta National Hospital Grounds, Next to National Public Health Laboratory Services (NPHLS).
              
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <a href="#"><img class="card-img-top" src="Admin/images/mom.jpg" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <a href="#">METAMAYWA</a>
              </h4>
              <p class="card-text">
              Cell Phone No: +254 716 775 229
              Moi Teaching and Referral Hospital, Along Nandi Road.
             </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <a href="#"><img class="card-img-top" src="Admin/images/test1.jpg" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <a href="#"> KIJAURI </a>
              </h4>
              <p class="card-text">
              Cell Phone No: +254 716 773 934
              Mzizima Road, Nyamira county General Hospital.
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <a href="#"><img class="card-img-top" src="Admin/images/embu.jpg" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <a href="#">MANGA </a>
              </h4>
              <p class="card-text">
              Cell Phone No: +254 716 775 232
              Along Manga-Nyansiongo Road, Next to Nyamira county General Hospital.
              </p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <a href="#"><img class="card-img-top" src="Admin/images/nak.jpg" alt=""></a>
            <div class="card-body">
              <h4 class="card-title">
                <a href=""> NYANSIONGO </a>
              </h4>
              <p class="card-text">
              Cell Phone No: +254 716 773 916
              Along NYANSIONGO road, next to Kijaui Provincial General Hospital Eye Unit.
              </p>
            </div>
          </div>
        </div>
        
        </div>
      </div>
      <!-- /.row -->

      
       
      </div>
      <!-- /.row -->

      <hr>

      

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
